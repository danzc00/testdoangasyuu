let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
〘 INFO BOT 〙
Dibuat dengan bahasa javascript via NodeJs

➥ Github: gada bero:v
➥ Instagram: [ TIDAK TERSEDIA]
➥ YouTube: HYUGA EDIT

〘 Thanks To 〙 
➥ Allah SWT

〘 DONASI 〙 
➥ pulsa : [ TIDAK TERSEDIA ]
➥ dana: [ TIDAK TERSEDIA ]
➥ ovo: [ TIDAK TERSEDIA ]


〘 BOT VIP 〙 
`.trim(), m)
}
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

